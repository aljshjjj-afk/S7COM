S7 CONTROL

1) ضع website داخل مجلد public باسم index.html.
2) انسخ .env.example إلى .env وضع توكن البوت و CLIENT_ID و GUILD_ID و ADMIN_ROLE_ID.
3) npm install
4) شغل الموقع: npm start
5) شغل البوت: npm run bot

أوامر Discord:
/hack add
/hack update
/hack remove
/announcement
/social

مهم: الموقع لازم يكون مستضاف على نفس السيرفر الذي يشغل server.js حتى /api/site يشتغل مباشرة. لا تضع توكن البوت داخل HTML.
