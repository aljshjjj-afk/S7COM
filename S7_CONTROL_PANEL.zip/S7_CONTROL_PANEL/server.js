const express=require('express');const path=require('path');const fs=require('fs');
const app=express();const PORT=process.env.PORT||3000;const DATA=path.join(__dirname,'site-data.json');
app.use(express.json({limit:'1mb'}));app.use(express.static(path.join(__dirname,'public')));
function read(){return JSON.parse(fs.readFileSync(DATA,'utf8'))}function write(x){fs.writeFileSync(DATA,JSON.stringify(x,null,2),'utf8')}
app.get('/api/site',(req,res)=>res.json(read()));
app.get('/api/health',(req,res)=>res.json({ok:true}));
// Optional protected API for non-Discord integrations.
app.post('/api/admin/update',(req,res)=>{if(!process.env.ADMIN_KEY||req.get('x-admin-key')!==process.env.ADMIN_KEY)return res.status(401).json({error:'unauthorized'});const d=read();Object.assign(d.site,req.body.site||{});if(Array.isArray(req.body.hacks))d.hacks=req.body.hacks;write(d);res.json({ok:true,data:d})});
app.listen(PORT,()=>console.log(`S7 site running on http://localhost:${PORT}`));
